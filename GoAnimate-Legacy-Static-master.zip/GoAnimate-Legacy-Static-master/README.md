# GoAnimate-Legacy-Static
Container for static the original HTML of the Legacy Video Maker hosted by GitHub Pages.  For this to work properly, you'll need to include certain rules on Requestly that I don't yet have a hold of.  If you're having trouble, feel free to let me know.

***It can be accessed [here](https://goanimate-wrapper.github.io/GoAnimate-Legacy-Static).***
